(() => {
  const $ = (id) => document.getElementById(id);

  const socket = io();
  let roomId = null;
  let color = 'spectator';
  let chess = null;
  let board = null;
  let ended = false;

  const roomInput = $('roomInput');
  const joinBtn = $('joinBtn');
  const gameEl = $('game');
  const roomLabel = $('roomLabel');
  const colorLabel = $('colorLabel');
  const turnLabel = $('turnLabel');
  const playersLabel = $('playersLabel');
  const notice = $('notice');
  const copyLinkBtn = $('copyLinkBtn');
  const restartBtn = $('restartBtn');
  const resignBtn = $('resignBtn');
  const backBtn = $('backBtn');
  const copyOk = $('copyOk');

  function updateStatus() {
    if (!chess) return;
    turnLabel.textContent = chess.turn() === 'w' ? 'White' : 'Black';

    let msg = '';
    if ((typeof chess.isCheckmate === 'function' && chess.isCheckmate()) ||
        (typeof chess.in_checkmate === 'function' && chess.in_checkmate())) {
      msg = 'Checkmate! ' + (chess.turn() === 'w' ? 'Black' : 'White') + ' wins';
    } else if ((typeof chess.isDraw === 'function' && chess.isDraw()) ||
               (typeof chess.in_draw === 'function' && chess.in_draw())) {
      msg = 'Draw';
    } else if ((typeof chess.isCheck === 'function' && chess.isCheck()) ||
               (typeof chess.in_check === 'function' && chess.in_check())) {
      msg = 'Check!';
    }
    if (ended && !msg) {
      msg = 'Game over';
    }
    notice.textContent = msg;
  }

  function onDragStart(source, piece) {
    if (!chess) return false;
    // disallow drag if game over
    const gameOver = (typeof chess.isGameOver === 'function' && chess.isGameOver()) ||
                     (typeof chess.game_over === 'function' && chess.game_over());
    if (gameOver || ended) return false;

    // only allow dragging own pieces, and only on your turn
    const turn = chess.turn();
    if (color === 'w' && piece.startsWith('b')) return false;
    if (color === 'b' && piece.startsWith('w')) return false;
    if ((color === 'w' && turn !== 'w') || (color === 'b' && turn !== 'b')) return false;

    return true;
  }

  function onDrop(source, target) {
    // attempt the move locally first to validate
    const move = chess.move({ from: source, to: target, promotion: 'q' });
    if (!move) return 'snapback';

    // emit to server
    socket.emit('move', { from: source, to: target, promotion: 'q' });
  }

  function onSnapEnd() {
    board.position(chess.fen());
    updateStatus();
  }

  function initBoard(fen) {
    if (!chess) chess = new window.Chess();
    if (fen) chess.load(fen);

    const cfg = {
      draggable: true,
      position: chess.fen(),
      orientation: color === 'b' ? 'black' : 'white',
      onDragStart,
      onDrop,
      onSnapEnd,
    };
    if (board) {
      board.orientation(color === 'b' ? 'black' : 'white');
      board.position(chess.fen());
    } else {
      board = window.Chessboard('board', cfg);
    }
    updateStatus();
  }

  joinBtn.addEventListener('click', () => {
    const val = (roomInput.value || '').trim();
    if (!val) {
      alert('Enter a room ID');
      return;
    }
    roomId = val;
    roomLabel.textContent = roomId;

    // switch UI
    document.querySelector('.lobby').classList.add('hidden');
    gameEl.classList.remove('hidden');

    socket.emit('join', roomId);
  });

  // URL auto-join: ?room=xyz
  (function autoJoinFromUrl() {
    const params = new URLSearchParams(location.search);
    const r = params.get('room');
    if (r) {
      roomId = r.trim();
      roomLabel.textContent = roomId;
      document.querySelector('.lobby').classList.add('hidden');
      gameEl.classList.remove('hidden');
      socket.emit('join', roomId);
    }
  })();

  // Socket events
  socket.on('error_message', (msg) => {
    alert(msg);
  });

  socket.on('init', (data) => {
    color = data.color || 'spectator';
    colorLabel.textContent = color === 'w' ? 'White' : color === 'b' ? 'Black' : 'Spectator';

    if (!chess) chess = new window.Chess();
    if (data.fen) chess.load(data.fen);
    ended = !!data.gameOver;

    initBoard(data.fen);
    updateStatus();
  });

  socket.on('players', ({ w, b }) => {
    const parts = [];
    parts.push(w ? 'White: joined' : 'White: waiting');
    parts.push(b ? 'Black: joined' : 'Black: waiting');
    playersLabel.textContent = parts.join(' | ');
  });

  socket.on('move', (state) => {
    if (!chess) chess = new window.Chess();
    if (state.fen) chess.load(state.fen);
    if (board) board.position(chess.fen());
    ended = !!(state.checkmate || state.draw || state.gameOver);
    updateStatus();
  });

  socket.on('illegal_move', ({ from, to }) => {
    // reload current position to snap back
    if (board && chess) board.position(chess.fen());
  });

  socket.on('restart', (state) => {
    if (!chess) chess = new window.Chess();
    if (state && state.fen) chess.load(state.fen);
    ended = false;
    if (board) board.position(chess.fen());
    notice.textContent = '';
    updateStatus();
  });

  socket.on('game_over', ({ reason, winner }) => {
    ended = true;
    let who = winner === 'w' ? 'White' : winner === 'b' ? 'Black' : 'Unknown';
    if (reason === 'resign') {
      notice.textContent = `Game over: ${who} wins by resignation`;
    } else {
      notice.textContent = 'Game over';
    }
    updateStatus();
  });

  // UI actions
  copyLinkBtn.addEventListener('click', async () => {
    if (!roomId) {
      alert('Join a room first');
      return;
    }
    const link = `${location.origin}/?room=${encodeURIComponent(roomId)}`;
    try {
      await navigator.clipboard.writeText(link);
      copyOk.style.display = 'inline';
      setTimeout(() => (copyOk.style.display = 'none'), 1200);
    } catch (e) {
      alert('Could not copy link');
    }
  });

  restartBtn.addEventListener('click', () => {
    socket.emit('restart');
  });

  resignBtn.addEventListener('click', () => {
    socket.emit('resign');
  });

  backBtn.addEventListener('click', () => {
    // Simple approach: reload to go back to lobby
    location.href = location.origin;
  });
})();
