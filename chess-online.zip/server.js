import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import { Chess } from 'chess.js';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

// In-memory room store
const rooms = new Map(); // roomId -> { chess, players: Map(socketId -> color), colorCount: { w: number, b: number }, ended: boolean }

function getOrCreateRoom(roomId) {
  if (!rooms.has(roomId)) {
    rooms.set(roomId, {
      chess: new Chess(),
      players: new Map(),
      colorCount: { w: 0, b: 0 },
      ended: false,
    });
  }
  return rooms.get(roomId);
}

function assignColor(room) {
  if (room.colorCount.w === 0) return 'w';
  if (room.colorCount.b === 0) return 'b';
  return 'spectator';
}

function getStateFromChess(chess) {
  const gameOver =
    (typeof chess.isGameOver === 'function' && chess.isGameOver()) ||
    (typeof chess.game_over === 'function' && chess.game_over()) ||
    false;
  const checkmate =
    (typeof chess.isCheckmate === 'function' && chess.isCheckmate()) ||
    (typeof chess.in_checkmate === 'function' && chess.in_checkmate()) ||
    false;
  const check =
    (typeof chess.isCheck === 'function' && chess.isCheck()) ||
    (typeof chess.in_check === 'function' && chess.in_check()) ||
    false;
  const draw =
    (typeof chess.isDraw === 'function' && chess.isDraw()) ||
    (typeof chess.in_draw === 'function' && chess.in_draw()) ||
    false;
  return { gameOver, checkmate, check, draw };
}

io.on('connection', (socket) => {
  let boundRoomId = null;

  socket.on('join', (roomId) => {
    if (typeof roomId !== 'string' || roomId.trim() === '') {
      socket.emit('error_message', 'Invalid room id');
      return;
    }
    boundRoomId = roomId.trim();
    const room = getOrCreateRoom(boundRoomId);

    socket.join(boundRoomId);

    const color = assignColor(room);
    if (color === 'w' || color === 'b') {
      room.players.set(socket.id, color);
      room.colorCount[color] += 1;
    }

    socket.emit('init', {
      color,
      fen: room.chess.fen(),
      turn: room.chess.turn(),
      gameOver:
        (typeof room.chess.isGameOver === 'function' && room.chess.isGameOver()) ||
        (typeof room.chess.game_over === 'function' && room.chess.game_over()) ||
        room.ended || false,
    });

    io.to(boundRoomId).emit('players', {
      w: [...room.players.values()].includes('w'),
      b: [...room.players.values()].includes('b'),
    });
  });

  socket.on('move', (payload) => {
    const roomId = boundRoomId;
    if (!roomId || !rooms.has(roomId)) return;
    const room = rooms.get(roomId);

    if (room.ended) return; // no moves allowed after game ended (resign)

    const color = room.players.get(socket.id);
    if (color !== 'w' && color !== 'b') return; // spectators can't move
    const turn = room.chess.turn();
    if (turn !== color) return; // not your turn

    const { from, to, promotion } = payload || {};
    if (typeof from !== 'string' || typeof to !== 'string') return;

    const move = room.chess.move({ from, to, promotion: promotion || 'q' });
    if (!move) {
      socket.emit('illegal_move', { from, to });
      return;
    }

    const state = {
      move,
      fen: room.chess.fen(),
      turn: room.chess.turn(),
      ...getStateFromChess(room.chess),
    };

    // If game is now over due to checkmate/draw, mark ended for clarity
    if (state.checkmate || state.draw || state.gameOver) {
      room.ended = true;
    }

    io.to(roomId).emit('move', state);
  });

  socket.on('resign', () => {
    const roomId = boundRoomId;
    if (!roomId || !rooms.has(roomId)) return;
    const room = rooms.get(roomId);
    const color = room.players.get(socket.id);
    if (color !== 'w' && color !== 'b') return;

    room.ended = true;
    const winner = color === 'w' ? 'b' : 'w';
    io.to(roomId).emit('game_over', { reason: 'resign', winner });
  });

  socket.on('restart', () => {
    const roomId = boundRoomId;
    if (!roomId || !rooms.has(roomId)) return;
    const room = rooms.get(roomId);
    room.chess = new Chess();
    room.ended = false;
    const state = {
      fen: room.chess.fen(),
      turn: room.chess.turn(),
      ...getStateFromChess(room.chess),
    };
    io.to(roomId).emit('restart', state);
  });

  socket.on('disconnect', () => {
    if (!boundRoomId) return;
    const room = rooms.get(boundRoomId);
    if (!room) return;

    const color = room.players.get(socket.id);
    if (color === 'w' || color === 'b') {
      room.colorCount[color] = Math.max(0, (room.colorCount[color] || 1) - 1);
      room.players.delete(socket.id);
      io.to(boundRoomId).emit('players', {
        w: [...room.players.values()].includes('w'),
        b: [...room.players.values()].includes('b'),
      });
    }

    // Optional: clean up empty rooms to free memory
    if (room.players.size === 0 && io.sockets.adapter.rooms.get(boundRoomId)?.size === 0) {
      rooms.delete(boundRoomId);
    }
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
